<?php

error_reporting (E_ALL ^ E_NOTICE ^ E_WARNING);
$conn=mysqli_connect('localhost','root','','pharmacy')or die("cannot connect to server");

?>